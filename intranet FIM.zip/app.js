/* =========================
   DONNÉES INITIALES
========================= */

const DEFAULT_USERS = {
  commandant: { password: "admin", role: "commandant", level: 5 },
  operateur: { password: "test", role: "operateur", level: 2 }
};

if (!localStorage.getItem("users")) {
  localStorage.setItem("users", JSON.stringify(DEFAULT_USERS));
}
if (!localStorage.getItem("reports")) {
  localStorage.setItem("reports", JSON.stringify([]));
}
if (!localStorage.getItem("logs")) {
  localStorage.setItem("logs", JSON.stringify([]));
}

let USERS = JSON.parse(localStorage.getItem("users"));
let currentUser = null;
let currentReport = null;

/* =========================
   LOGIN
========================= */

document.getElementById("loginBtn").addEventListener("click", login);

function login() {
  const u = loginUser.value.trim();
  const p = loginPass.value.trim();

  if (!USERS[u] || USERS[u].password !== p) {
    alert("ACCÈS REFUSÉ");
    return;
  }

  currentUser = { name: u, ...USERS[u] };
  localStorage.setItem("session", JSON.stringify(currentUser));

  document.getElementById("login").classList.add("hidden");
  document.getElementById("dashboard").classList.remove("hidden");

  loadReports();
  logAction("Connexion");
}

/* =========================
   SESSION AUTO
========================= */

const savedSession = JSON.parse(localStorage.getItem("session"));
if (savedSession) {
  currentUser = savedSession;
  document.getElementById("login").classList.add("hidden");
  document.getElementById("dashboard").classList.remove("hidden");
  loadReports();
}

/* =========================
   RAPPORTS
========================= */

document.getElementById("createReportBtn").addEventListener("click", createReport);

function createReport() {
  if (!reportTitle.value || !reportContent.value) {
    alert("Champs manquants");
    return;
  }

  const reports = JSON.parse(localStorage.getItem("reports"));

  reports.push({
    id: Date.now(),
    title: reportTitle.value,
    content: reportContent.value,
    unit: reportUnit.value,
    level: parseInt(reportLevel.value),
    author: currentUser.name,
    date: new Date().toLocaleString()
  });

  localStorage.setItem("reports", JSON.stringify(reports));
  logAction("Création rapport");

  reportTitle.value = "";
  reportContent.value = "";

  loadReports();
}

function loadReports() {
  reportList.innerHTML = "";
  const reports = JSON.parse(localStorage.getItem("reports"));

  reports.forEach(r => {
    const div = document.createElement("div");
    div.className = "report";
    div.textContent = `[${r.unit}] ${r.title}`;
    div.onclick = () => openReport(r);
    reportList.appendChild(div);
  });
}

function openReport(report) {
  if (currentUser.level < report.level) {
    showDenied();
    logAction("Accès refusé rapport");
    return;
  }

  currentReport = report;
  modalTitle.textContent = report.title;
  modalMeta.textContent = `${report.author} — ${report.unit} — Niveau ${report.level}`;
  modalContent.textContent = report.content;

  reportModal.classList.remove("hidden");
  logAction("Consultation rapport");
}

document.getElementById("closeModalBtn").addEventListener("click", () => {
  reportModal.classList.add("hidden");
});

document.getElementById("exportPdfBtn").addEventListener("click", () => {
  logAction("Export PDF");
  window.print();
});

/* =========================
   ACCÈS REFUSÉ
========================= */

function showDenied() {
  accessDenied.classList.remove("hidden");
  setTimeout(() => accessDenied.classList.add("hidden"), 2500);
}

/* =========================
   LOGS
========================= */

function logAction(action) {
  const logs = JSON.parse(localStorage.getItem("logs"));
  logs.push({
    user: currentUser.name,
    action,
    date: new Date().toLocaleString()
  });
  localStorage.setItem("logs", JSON.stringify(logs));
}
