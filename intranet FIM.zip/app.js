/* =========================
   INITIALISATION DES DONNÉES
========================= */

async function loadInitialData() {
  const storedUsers = localStorage.getItem("users");
  const storedReports = localStorage.getItem("reports");

  if (!storedUsers || !storedReports) {
    const res = await fetch("data.json");
    const data = await res.json();

    localStorage.setItem("users", JSON.stringify(data.users));
    localStorage.setItem("reports", JSON.stringify(data.reports));
    localStorage.setItem("logs", JSON.stringify([]));
  }
}

loadInitialData();

/* =========================
   VARIABLES GLOBALES
========================= */

let USERS = JSON.parse(localStorage.getItem("users")) || {};
let currentUser = null;
let currentReport = null;

/* =========================
   LOGIN / SESSION
========================= */

document.getElementById("loginBtn").addEventListener("click", login);

function login() {
  const u = loginUser.value.trim();
  const p = loginPass.value.trim();

  if (!USERS[u] || USERS[u].password !== p) {
    alert("Accès refusé");
    return;
  }

  currentUser = { name: u, ...USERS[u] };
  localStorage.setItem("session", JSON.stringify(currentUser));

  login.style.display = "none";
  dashboard.classList.remove("hidden");

  loadReports();
}

const savedSession = JSON.parse(localStorage.getItem("session"));
if (savedSession) {
  currentUser = savedSession;
  login.style.display = "none";
  dashboard.classList.remove("hidden");
  loadReports();
}

/* =========================
   RAPPORTS
========================= */

document.getElementById("createReportBtn").addEventListener("click", createReport);

function createReport() {
  const reports = JSON.parse(localStorage.getItem("reports")) || [];

  reports.push({
    id: Date.now(),
    title: reportTitle.value,
    content: reportContent.value,
    unit: reportUnit.value,
    level: parseInt(reportLevel.value),
    author: currentUser.name,
    date: new Date().toLocaleString()
  });

  localStorage.setItem("reports", JSON.stringify(reports));
  logAction("Création rapport");

  reportTitle.value = "";
  reportContent.value = "";

  loadReports();
}

function loadReports() {
  reportList.innerHTML = "";
  const reports = JSON.parse(localStorage.getItem("reports")) || [];

  reports.forEach(r => {
    const div = document.createElement("div");
    div.className = "report";
    div.innerText = `[${r.unit}] ${r.title}`;
    div.onclick = () => openReport(r);
    reportList.appendChild(div);
  });
}

function openReport(report) {
  if (currentUser.level < report.level) {
    showDenied();
    logAction("Accès refusé rapport");
    return;
  }

  currentReport = report;
  modalTitle.innerText = report.title;
  modalMeta.innerText = `${report.author} — ${report.unit} — Niveau ${report.level}`;
  modalContent.innerText = report.content;
  reportModal.classList.remove("hidden");

  logAction("Consultation rapport");
}

function closeModal() {
  reportModal.classList.add("hidden");
}

document.getElementById("exportPdfBtn").addEventListener("click", () => {
  logAction("Export PDF rapport");
  window.print();
});

/* =========================
   ACCÈS REFUSÉ
========================= */

function showDenied() {
  accessDenied.classList.remove("hidden");
  setTimeout(() => accessDenied.classList.add("hidden"), 2500);
}

/* =========================
   LOGS
========================= */

function logAction(action) {
  const logs = JSON.parse(localStorage.getItem("logs")) || [];
  logs.push({
    user: currentUser.name,
    action,
    date: new Date().toLocaleString()
  });
  localStorage.setItem("logs", JSON.stringify(logs));
}
