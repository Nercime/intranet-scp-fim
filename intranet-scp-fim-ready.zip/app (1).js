// App JavaScript — robuste, attend le DOM et vérifie l'existence des éléments.
document.addEventListener('DOMContentLoaded', () => {

  // Sélecteurs
  const loginBox = document.getElementById("login");
  const dashboard = document.getElementById("dashboard");
  const loginUser = document.getElementById("loginUser");
  const loginPass = document.getElementById("loginPass");
  const loginBtn  = document.getElementById("loginBtn");
  const saveBtn   = document.getElementById("saveBtn");
  const unit      = document.getElementById("unit");
  const title     = document.getElementById("title");
  const content   = document.getElementById("content");
  const reportsDiv = document.getElementById("reports");
  const filterUnit = document.getElementById("filterUnit");
  const manageUsersCard = document.getElementById("manageUsersCard");
  const newUser = document.getElementById("newUser");
  const newPass = document.getElementById("newPass");
  const newRole = document.getElementById("newRole");
  const newUnit = document.getElementById("newUnit");
  const newRank = document.getElementById("newRank");
  const createUserBtn = document.getElementById("createUserBtn");

  // Données utilisateurs par défaut
  const USERS = {
    "commandant": { password: "scp", role: "admin", unit: "ALL", rank: "Commandant" },
    "operateur": { password: "fim", role: "user", unit: "NU-7", rank: "Soldat" }
  };

  let currentUser = null;

  // Handler login — vérifie que les éléments existent avant utilisation
  function handleLogin() {
    if (!loginUser || !loginPass) return;
    const u = loginUser.value.trim();
    const p = loginPass.value.trim();

    if (USERS[u] && USERS[u].password === p) {
      currentUser = u;
      if (loginBox) loginBox.classList.add("hidden");

      // Si non-admin : bloquer le choix d'unité pour l'utilisateur
      if (USERS[currentUser].role !== "admin") {
        if (unit) {
          unit.value = USERS[currentUser].unit;
          unit.disabled = true;
        }
      } else {
        if (manageUsersCard) manageUsersCard.classList.remove("hidden");
      }

      if (filterUnit) filterUnit.addEventListener("change", loadReports);
      if (dashboard) dashboard.classList.remove("hidden");
      loadReports();
    } else {
      alert("Accès refusé — Identifiants invalides");
    }
  }

  // Sauvegarde d'un rapport
  function saveReport() {
    if (!title || !content) return;
    if (!title.value || !content.value) { alert("Titre et contenu obligatoires"); return; }
    const reports = JSON.parse(localStorage.getItem("reports") || "[]");
    reports.push({ author: currentUser, unit: unit ? unit.value : 'ALL', title: title.value, content: content.value, date: new Date().toLocaleString() });
    localStorage.setItem("reports", JSON.stringify(reports));
    title.value = ""; content.value = "";
    loadReports();
  }

  // Chargement et affichage des rapports
  function loadReports() {
    const reports = JSON.parse(localStorage.getItem("reports") || "[]");
    if (!reportsDiv) return;
    reportsDiv.innerHTML = "";
    const userRole = USERS[currentUser]?.role;
    const userUnit = USERS[currentUser]?.unit;
    const filter = filterUnit ? filterUnit.value : "ALL";

    reports.forEach((r, idx) => {
      if (userRole !== "admin" && r.unit !== userUnit) return;
      if (filter !== "ALL" && r.unit !== filter) return;

      const div = document.createElement("div");
      div.className = "card";
      const meta = document.createElement("div");
      meta.innerHTML = `<strong>[${r.unit}]</strong> ${escapeHtml(r.title)}<br>`;
      const small = document.createElement("small");
      small.textContent = `${r.author} — ${USERS[r.author]?.rank || ''} — ${r.date}`;
      const p = document.createElement("p");
      p.textContent = r.content;

      div.appendChild(meta);
      div.appendChild(small);
      div.appendChild(p);

      // Bouton supprimer visible seulement aux admins
      if (userRole === 'admin') {
        const delBtn = document.createElement("button");
        delBtn.textContent = 'Supprimer';
        delBtn.addEventListener('click', () => deleteReport(idx));
        div.appendChild(delBtn);
      }

      reportsDiv.appendChild(div);
    });
  }

  // Suppression d'un rapport par index (index dans le tableau original)
  function deleteReport(idx) {
    const reports = JSON.parse(localStorage.getItem("reports") || "[]");
    if (idx >= 0 && idx < reports.length) {
      reports.splice(idx, 1);
      localStorage.setItem("reports", JSON.stringify(reports));
      loadReports();
    }
  }

  // Création / modification d'utilisateur
  function createUser() {
    if (!newUser || !newPass || !newRole || !newUnit || !newRank) return;
    const u = newUser.value.trim();
    const p = newPass.value.trim();
    const role = newRole.value;
    const unitVal = newUnit.value;
    const rankVal = newRank.value || '';

    if (!u || !p) { alert("Identifiant et mot de passe obligatoires"); return; }
    USERS[u] = { password: p, role: role, unit: unitVal, rank: rankVal };
    alert(`Utilisateur ${u} créé / modifié avec succès`);
    newUser.value = ''; newPass.value = ''; newRole.value = 'user'; newUnit.value='NU-7'; newRank.value='';
    loadReports();
  }

  // Petit utilitaire pour échapper le HTML (sécurité basique)
  function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>"'`=\/]/g, function(s) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
        '/': '&#x2F;',
        '`': '&#x60;',
        '=': '&#x3D;'
      }[s];
    });
  }

  // Attacher handlers si les éléments existent
  if (loginBtn) loginBtn.addEventListener("click", handleLogin);
  if (saveBtn) saveBtn.addEventListener("click", saveReport);
  if (createUserBtn) createUserBtn.addEventListener("click", createUser);

  // Optionnel : pré-remplir quelques rapports d'exemple si nécessaire (décommenter)
  // if (!localStorage.getItem("reports")) {
  //   localStorage.setItem("reports", JSON.stringify([
  //     { author: 'operateur', unit: 'NU-7', title: 'Test', content: 'Contenu test', date: new Date().toLocaleString() }
  //   ]));
  // }

});