const USERS = {
  commandant: { password: "admin", role: "commandant", level: 5 },
  operateur: { password: "test", role: "operateur", level: 2 }
};

let currentUser = null;
let currentReport = null;

function login() {
  const u = loginUser.value;
  const p = loginPass.value;

  if (!USERS[u] || USERS[u].password !== p) {
    alert("Accès refusé");
    return;
  }

  currentUser = { name: u, ...USERS[u] };
  document.getElementById("login").classList.add("hidden");
  document.getElementById("dashboard").classList.remove("hidden");
  loadReports();
}

function createReport() {
  const reports = JSON.parse(localStorage.getItem("reports") || "[]");

  reports.push({
    id: Date.now(),
    title: reportTitle.value,
    content: reportContent.value,
    unit: reportUnit.value,
    level: parseInt(reportLevel.value),
    author: currentUser.name,
    date: new Date().toLocaleString()
  });

  localStorage.setItem("reports", JSON.stringify(reports));
  reportTitle.value = "";
  reportContent.value = "";
  loadReports();
}

function loadReports() {
  reportList.innerHTML = "";
  const reports = JSON.parse(localStorage.getItem("reports") || "[]");

  reports.forEach(r => {
    const div = document.createElement("div");
    div.className = "report";
    div.innerText = `[${r.unit}] ${r.title}`;
    div.onclick = () => openReport(r);
    reportList.appendChild(div);
  });
}

function openReport(report) {
  if (currentUser.level < report.level) {
    showDenied();
    return;
  }

  currentReport = report;
  modalTitle.innerText = report.title;
  modalMeta.innerText = `${report.author} — ${report.unit} — Niveau ${report.level}`;
  modalContent.innerText = report.content;
  reportModal.classList.remove("hidden");

  logAction(`Consultation rapport ${report.id}`);
}

function closeModal() {
  reportModal.classList.add("hidden");
}

function exportPDF() {
  logAction(`Export PDF rapport ${currentReport.id}`);
  window.print();
}

function showDenied() {
  accessDenied.classList.remove("hidden");
  setTimeout(() => accessDenied.classList.add("hidden"), 2500);
}

function logAction(action) {
  const logs = JSON.parse(localStorage.getItem("logs") || "[]");
  logs.push({
    user: currentUser.name,
    action,
    date: new Date().toLocaleString()
  });
  localStorage.setItem("logs", JSON.stringify(logs));
}
